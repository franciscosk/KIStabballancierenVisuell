
import com.soywiz.klock.TimeSpan
import com.soywiz.korag.shader.Program
import com.soywiz.korev.Key
import com.soywiz.korev.MouseEvent
import com.soywiz.korge.Korge
import com.soywiz.korge.box2d.body
import com.soywiz.korge.box2d.nearestBox2dWorld
import com.soywiz.korge.box2d.registerBody
import com.soywiz.korge.box2d.registerBodyWithFixture
import com.soywiz.korge.time.delay
import com.soywiz.korge.view.*
import com.soywiz.korim.color.Colors
import com.soywiz.korim.text.TextAlignment
import com.soywiz.korio.async.delay
import com.soywiz.korma.geom.Angle
import com.soywiz.korma.geom.degrees
import kotlinx.coroutines.isActive
import org.jbox2d.common.Vec2
import org.jbox2d.dynamics.BodyDef
import org.jbox2d.dynamics.BodyType
import org.jbox2d.dynamics.joints.*
import org.jbox2d.pooling.IWorldPool
import org.jbox2d.pooling.normal.DefaultWorldPool
import kotlin.math.*

suspend fun fitnessVisuell(netz: Netzwerk,generation: Int = 1, genom: Int = 1)  =  Korge(width = 1920, height = 1080, bgcolor = Colors["#2b2b2b"]){

        macheNetzMagie(netz, this,generation,genom);


}

 suspend fun macheNetzMagie(netz : Netzwerk, stage: Stage, generation: Int, genom: Int) {


     var zeit = 0.0
     val zeitschritt= 0.02
     val g= 9.81
     var wagenX =0.0
     var wagenV =0.0
     var wagenA= 0.0
     val wagenMasse= 1

     var stabRotation= 0.0
     var stabWinkelgeschwindigkeit=0.0
     var stabWinkelbeschleunigung = 0.0
     val stabMasse= 0.1
     var stabHalbeLaenge= 0.5

     val streckenGrenze = 2.4
     val drehGrenze = 0.209
     val kraft = 10.0
var vergrösserungsFaktor = 400
     var hoeheStab=vergrösserungsFaktor*stabHalbeLaenge
     var breiteStab=hoeheStab/20
     var hoeheWagen=hoeheStab/10
     var breiteWagen= hoeheStab/5

var zeitText = stage.text(zeit.toString())
     var generationText= stage.text("Generation $generation")
     generationText.y= 20.0
     var genomText= stage.text("Genom $genom")
     genomText.y= 40.0
     //stage.addChild(generationText)

     var cart = stage.solidRect(breiteWagen, hoeheWagen).apply {
         position(250, 1000)
         rotation(Angle(0.0))
         color=Colors.RED
         registerBodyWithFixture(type = BodyType.STATIC,friction = 0.00,fixedRotation = true)

     }
     var pole = stage.solidRect(breiteStab, hoeheStab).apply {
         position(250, 1000)
         rotation(Angle(0.0) )
         registerBodyWithFixture(type = BodyType.STATIC,friction = 0.01)
         color=Colors.BLUE
     }

     var aBewegungen=0
     while(wagenX>=-streckenGrenze && wagenX<=streckenGrenze && stabRotation<drehGrenze && stabRotation>-drehGrenze && aBewegungen<50000){
         delay(TimeSpan(20.0))

         if(stage.keys.justReleased(Key.A)){stabRotation+= 0.05}
         if(stage.keys.justReleased(Key.S)){stabRotation-= 0.05}
         var angewendeteKraft:Double
         var output= netz.rechnen(doubleArrayOf(wagenX,wagenV,stabRotation,stabWinkelgeschwindigkeit))

         if (output[0]<output[1])  angewendeteKraft= kraft
         else                      angewendeteKraft= -kraft

         stabWinkelbeschleunigung= ((g* sin(stabRotation)+ cos(stabRotation)*((-angewendeteKraft-stabMasse*stabHalbeLaenge*stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation))/(wagenMasse+stabMasse) ))/(stabHalbeLaenge*((4/3)-(stabMasse*cos(stabRotation).pow(2))/(wagenMasse+stabMasse))))
         wagenA= ((angewendeteKraft+stabMasse*stabHalbeLaenge*((stabWinkelgeschwindigkeit.pow(2)*sin(stabRotation))-(stabWinkelbeschleunigung*cos(stabRotation))))/(wagenMasse+stabMasse))
         wagenX += zeitschritt*wagenV
         wagenV += zeitschritt*wagenA

         stabRotation+= zeitschritt*stabWinkelgeschwindigkeit
         stabWinkelgeschwindigkeit += zeitschritt*stabWinkelbeschleunigung

         pole.rotation=Angle(stabRotation+PI)
         pole.x=vergrösserungsFaktor*(wagenX+2.4)
cart.x=vergrösserungsFaktor*(wagenX+2.4)-0.5*breiteWagen


         aBewegungen++
         zeit+= zeitschritt
zeitText.text=zeit.toString()
        // generationText.text= generation.toString()

     }
     netz.fitness= aBewegungen.toDouble()
println(netz.fitness)








 }


